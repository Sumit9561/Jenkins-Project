package com.briz.sprinboot_ngrok_testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinbootNgrokTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinbootNgrokTestingApplication.class, args);
	}

}
